Juan Felipe Garc�a Mart�nez.

Aplicaci�n web:

La aplicacion Web se inicia con un men� en su pagina principal (index.xhtml), a partir de este men� se puede dirigir tanto a la informaci�n de estudiante, como a la informaci�n de curso.
Una vez se llega a cualquiera de estas dos paginas, se encuentra un formulario para insertar, editar, eliminar y buscar informacion correspondiente a la tabla que se encuentra en la parte
inferior del formulario. En la parte superior de cada p�gina (Debajo del titulo) se encuentra una barra de navegacion que permite al usuario moverse entre las diferentes p�ginas de la aplicaci�n.
Los formularios interactuan con la informaci�n de dos tablas en una base de datos y la presentan en la pagina web, si se inserta informaci�n aparecera una nueva fila en la tabla, al eliminar 
una fila (lo cual se logra mediante la llave primaria) esta desaparece de la tabla, al editar se modifican los campos deseados (Tambien mediante la llave primaria) y al buscar, los campos 
del formulario se llenan con la informaci�n solicitada.
